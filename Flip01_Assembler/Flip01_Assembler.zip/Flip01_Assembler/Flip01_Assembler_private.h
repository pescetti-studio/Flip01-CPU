/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef FLIP01_ASSEMBLER_PRIVATE_H
#define FLIP01_ASSEMBLER_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.0.1.19"
#define VER_MAJOR	1
#define VER_MINOR	0
#define VER_RELEASE	1
#define VER_BUILD	19
#define COMPANY_NAME	"Pescetti Studio"
#define FILE_VERSION	"1.0.1.19"
#define FILE_DESCRIPTION	"A small assembler for the Flip01 CPU"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	"Copyright (c) 2024 Pescetti Studio (Biasolo Riccardo & Croci Lorenzo)"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"Flip01 Assembler - Pescetti Studio"
#define PRODUCT_VERSION	"1.0.1.19"

#endif /*FLIP01_ASSEMBLER_PRIVATE_H*/
